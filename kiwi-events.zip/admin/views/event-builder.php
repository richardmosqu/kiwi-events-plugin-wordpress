<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Enqueue styles for the builder
wp_enqueue_style( 'ke-event-builder-css', KE_PLUGIN_URL . 'admin/css/ke-event-builder.css', array(), KE_VERSION );

// Ensure WP media uploader is loaded
wp_enqueue_media();

wp_enqueue_script( 'ke-event-builder-js', KE_PLUGIN_URL . 'admin/js/ke-event-builder.js', array( 'jquery' ), KE_VERSION, true );
wp_localize_script( 'ke-event-builder-js', 'keBuilderData', array(
    'restUrl' => esc_url_raw( rest_url( 'ke/v1/' ) ),
    'nonce'   => wp_create_nonce( 'wp_rest' ),
    'homeUrl' => home_url(),
));

$event_id = isset( $_GET['event_id'] ) ? absint( $_GET['event_id'] ) : 0;
// We would ideally fetch existing event data here if $event_id > 0, to prefill the form.
// For the sake of this prototype, we'll initialize empty or lean heavily on JS to fetch it via REST.
?>

<div class="wrap ke-builder-wrap">
    
    <div class="ke-builder-header">
        <div class="ke-builder-title">
            <a href="<?php echo admin_url('edit.php?post_type=ke_event'); ?>" class="back-link">
                <span class="dashicons dashicons-arrow-left-alt2"></span> Back
            </a>
            <h1><?php echo $event_id ? 'Edit Event' : 'Create New Event'; ?></h1>
        </div>
        <div class="ke-builder-actions">
            <button id="ke-builder-save-draft" class="ke-btn ke-btn-secondary">Save Draft</button>
            <button id="ke-builder-publish" class="ke-btn ke-btn-primary">Publish Event</button>
        </div>
    </div>

    <div class="ke-builder-main">
        <!-- Stepper Sidebar -->
        <aside class="ke-builder-sidebar">
            <ul class="ke-stepper">
                <li class="ke-step active" data-step="1">
                    <span class="step-icon">1</span>
                    <span class="step-label">Event Basics</span>
                </li>
                <li class="ke-step" data-step="2">
                    <span class="step-icon">2</span>
                    <span class="step-label">Time & Location</span>
                </li>
                <li class="ke-step" data-step="3">
                    <span class="step-icon">3</span>
                    <span class="step-label">Taxonomy & Details</span>
                </li>
                <li class="ke-step" data-step="4">
                    <span class="step-icon">4</span>
                    <span class="step-label">Ticketing & Capacity</span>
                </li>
            </ul>
        </aside>

        <!-- Builder Content -->
        <div class="ke-builder-content">
            <form id="ke-event-builder-form">
                <input type="hidden" name="event_id" value="<?php echo esc_attr( $event_id ); ?>">
                
                <!-- STEP 1: BASICS -->
                <div class="ke-step-panel active" id="step-1">
                    <h2>Event Basics</h2>
                    <p class="step-desc">Start by giving your event a catchy title and an eye-catching banner.</p>

                    <div class="form-group">
                        <label>Event Name <span>*</span></label>
                        <input type="text" name="event_title" class="ke-input-large" placeholder="E.g., Summer Music Festival 2026" required>
                    </div>

                    <div class="form-group">
                        <label>Event Banner Image</label>
                        <div class="ke-image-uploader" id="ke-banner-uploader">
                            <div class="uploader-preview"></div>
                            <button type="button" class="ke-btn ke-btn-secondary">Choose Image</button>
                            <input type="hidden" name="event_banner_id" id="event_banner_id">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Event Description</label>
                        <?php 
                        wp_editor( '', 'event_description', array(
                            'media_buttons' => false,
                            'textarea_rows' => 8,
                            'teeny'         => true,
                        ) ); 
                        ?>
                    </div>
                </div>

                <!-- STEP 2: TIME & LOCATION -->
                <div class="ke-step-panel" id="step-2">
                    <h2>Time & Location</h2>
                    <p class="step-desc">When and where is this event taking place?</p>

                    <div class="ke-flex-row">
                        <div class="form-group half">
                            <label>Start Date & Time <span>*</span></label>
                            <input type="datetime-local" name="event_start" required>
                        </div>
                        <div class="form-group half">
                            <label>End Date & Time <span>*</span></label>
                            <input type="datetime-local" name="event_end" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Timezone <span>*</span></label>
                        <select name="event_timezone">
                            <?php foreach ( timezone_identifiers_list() as $tz ) : ?>
                                <option value="<?php echo esc_attr($tz); ?>" <?php selected(wp_timezone_string(), $tz); ?>><?php echo esc_html(str_replace('_', ' ', $tz)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <hr>

                    <div class="form-group">
                        <label>Location Type</label>
                        <div class="ke-toggle-group">
                            <label><input type="radio" name="location_type" value="venue" checked> In-Person</label>
                            <label><input type="radio" name="location_type" value="virtual"> Virtual</label>
                            <label><input type="radio" name="location_type" value="hybrid"> Hybrid</label>
                        </div>
                    </div>

                    <div id="venue-fields" class="conditional-fields">
                        <div class="form-group">
                            <label>Venue Name</label>
                            <input type="text" name="event_venue" placeholder="E.g., Central Park">
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <input type="text" name="event_address" placeholder="E.g., 123 Main St">
                        </div>
                    </div>

                    <div id="virtual-fields" class="conditional-fields" style="display:none;">
                        <div class="form-group">
                            <label>Virtual Event URL</label>
                            <input type="url" name="event_virtual_url" placeholder="E.g., https://zoom.us/...">
                            <small>Will be shared with ticket holders automatically.</small>
                        </div>
                    </div>
                </div>

                <!-- STEP 3: TAXONOMY & DETAILS -->
                <div class="ke-step-panel" id="step-3">
                    <h2>Taxonomy & Additional Details</h2>
                    <p class="step-desc">Categorize your event to help attendees find it.</p>

                    <div class="form-group">
                        <label>Categories</label>
                        <?php 
                        $categories = get_terms( array( 'taxonomy' => 'ke_event_category', 'hide_empty' => false ) );
                        if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
                            echo '<div class="ke-checkbox-grid">';
                            foreach ( $categories as $cat ) {
                                echo '<label><input type="checkbox" name="event_categories[]" value="' . esc_attr( $cat->term_id ) . '"> ' . esc_html( $cat->name ) . '</label>';
                            }
                            echo '</div>';
                        } else {
                            echo '<p>No categories found. Create some in the Categories menu.</p>';
                        }
                        ?>
                    </div>

                    <div class="form-group">
                        <label>Organizer</label>
                        <?php 
                        $organizers = get_terms( array( 'taxonomy' => 'ke_organizer', 'hide_empty' => false ) );
                        if ( ! empty( $organizers ) && ! is_wp_error( $organizers ) ) {
                            echo '<select name="event_organizer"><option value="">Select Organizer...</option>';
                            foreach ( $organizers as $org ) {
                                echo '<option value="' . esc_attr( $org->term_id ) . '">' . esc_html( $org->name ) . '</option>';
                            }
                            echo '</select>';
                        } else {
                            echo '<p>No organizers found.</p>';
                        }
                        ?>
                    </div>
                </div>

                <!-- STEP 4: TICKETING -->
                <div class="ke-step-panel" id="step-4">
                    <h2>Ticketing & Capacity</h2>
                    <p class="step-desc">Configure your tickets, pricing, and availability.</p>

                    <div class="ke-flex-row">
                        <div class="form-group half">
                            <label>Total Event Capacity</label>
                            <input type="number" name="event_capacity" placeholder="0 = unlimited">
                        </div>
                        <div class="form-group half">
                            <label>Max Tickets per Person</label>
                            <input type="number" name="event_max_tickets" value="10">
                        </div>
                    </div>

                    <hr>

                    <h3>Ticket Types</h3>
                    <div id="ke-ticket-types-container">
                        <!-- Ticket types will be rendered here dynamically via JS -->
                        <div class="ke-empty-state">No tickets added yet.</div>
                    </div>
                    
                    <button type="button" class="ke-btn ke-btn-secondary" id="ke-add-ticket-type">
                        + Add Ticket Type
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
