<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap ke-wrap">
    <div class="ke-dashboard-header">
        <div>
            <h1>👥 Attendees</h1>
            <p class="ke-subtitle">View and manage event attendees</p>
        </div>
        <div class="ke-header-actions">
            <?php if ( $event_id ) : ?>
                <a href="<?php echo esc_url( add_query_arg( 'ke_export_csv', '1' ) ); ?>" class="button">
                    📥 Export CSV
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Filters -->
    <div class="ke-card ke-filters">
        <form method="get" action="">
            <input type="hidden" name="page" value="kiwi-events-attendees">
            <div class="ke-filter-row">
                <div class="ke-filter-field">
                    <label>Event</label>
                    <select name="event_id" onchange="this.form.submit()">
                        <option value="0">— Select Event —</option>
                        <?php foreach ( $events as $event ) : ?>
                            <option value="<?php echo esc_attr( $event->ID ); ?>" <?php selected( $event_id, $event->ID ); ?>>
                                <?php echo esc_html( $event->post_title ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php if ( $event_id ) : ?>
                    <div class="ke-filter-field">
                        <label>Status</label>
                        <select name="status">
                            <option value="">All</option>
                            <option value="valid" <?php selected( $status_filter, 'valid' ); ?>>Valid</option>
                            <option value="used" <?php selected( $status_filter, 'used' ); ?>>Checked In</option>
                            <option value="cancelled" <?php selected( $status_filter, 'cancelled' ); ?>>Cancelled</option>
                        </select>
                    </div>

                    <?php if ( ! empty( $types ) ) : ?>
                        <div class="ke-filter-field">
                            <label>Ticket Type</label>
                            <select name="ticket_type_id">
                                <option value="0">All Types</option>
                                <?php foreach ( $types as $type ) : ?>
                                    <option value="<?php echo esc_attr( $type->id ); ?>" <?php selected( $type_filter, $type->id ); ?>>
                                        <?php echo esc_html( $type->name ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <div class="ke-filter-field">
                        <label>Search</label>
                        <input type="text" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Name, email, or ticket code...">
                    </div>

                    <div class="ke-filter-field ke-filter-submit">
                        <button type="submit" class="button button-primary">Filter</button>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=kiwi-events-attendees&event_id=' . $event_id ) ); ?>" class="button">Reset</a>
                    </div>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <?php if ( ! $event_id ) : ?>
        <div class="ke-card">
            <p class="ke-empty-state">Select an event above to view its attendees.</p>
        </div>
    <?php elseif ( empty( $attendees ) ) : ?>
        <div class="ke-card">
            <p class="ke-empty-state">No attendees found for the selected criteria.</p>
        </div>
    <?php else : ?>
        <!-- Stats summary -->
        <div class="ke-kpi-grid ke-kpi-mini">
            <div class="ke-kpi-card">
                <div class="ke-kpi-content">
                    <span class="ke-kpi-label">Total Attendees</span>
                    <span class="ke-kpi-value"><?php echo intval( $total ); ?></span>
                </div>
            </div>
        </div>

        <!-- Attendees Table -->
        <div class="ke-card">
            <table class="ke-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Ticket Type</th>
                        <th>Ticket Code</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Checked In</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $attendees as $a ) : ?>
                        <tr>
                            <td><?php echo intval( $a->attendee_number ); ?></td>
                            <td><strong><?php echo esc_html( $a->attendee_name ); ?></strong></td>
                            <td><?php echo esc_html( $a->attendee_email ); ?></td>
                            <td><?php echo esc_html( $a->ticket_type_name ); ?></td>
                            <td><code style="font-size:10px;"><?php echo esc_html( substr( $a->ticket_code, 0, 16 ) ); ?>…</code></td>
                            <td><?php echo $a->ticket_price > 0 ? '$' . number_format( $a->ticket_price, 2 ) : '<span class="ke-badge ke-badge-free">Free</span>'; ?></td>
                            <td>
                                <span class="ke-badge ke-badge-<?php echo esc_attr( $a->status ); ?>">
                                    <?php
                                    echo match( $a->status ) {
                                        'valid'     => '🟢 Valid',
                                        'used'      => '✅ Checked In',
                                        'cancelled' => '❌ Cancelled',
                                        default     => ucfirst( $a->status ),
                                    };
                                    ?>
                                </span>
                            </td>
                            <td><?php echo $a->checked_in_at ? date( 'M j, g:i A', strtotime( $a->checked_in_at ) ) : '—'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <?php if ( $total_pages > 1 ) : ?>
                <div class="ke-pagination">
                    <?php
                    $base_url = admin_url( 'admin.php?page=kiwi-events-attendees&event_id=' . $event_id );
                    if ( $status_filter ) $base_url .= '&status=' . $status_filter;
                    if ( $type_filter )   $base_url .= '&ticket_type_id=' . $type_filter;
                    if ( $search )        $base_url .= '&s=' . urlencode( $search );
                    ?>
                    <?php for ( $i = 1; $i <= $total_pages; $i++ ) : ?>
                        <a href="<?php echo esc_url( $base_url . '&paged=' . $i ); ?>"
                           class="ke-page-link <?php echo $i === $page_num ? 'active' : ''; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
