/**
 * KiwiEvents - Event Builder Logic
 */
jQuery(document).ready(function($) {

    // 1. Navigation Logic
    const $steps = $('.ke-step');
    const $panels = $('.ke-step-panel');

    $steps.on('click', function() {
        // Simple validation: Ensure current step is somewhat valid before jumping (Optional)
        // For now, allow free movement
        const targetStep = $(this).data('step');
        
        $steps.removeClass('active');
        $(this).addClass('active');

        $panels.removeClass('active');
        $('#step-' + targetStep).addClass('active');
    });

    // 2. Conditional Fields for Location
    $('input[name="location_type"]').on('change', function() {
        const val = $(this).val();
        if (val === 'venue') {
            $('#venue-fields').slideDown();
            $('#virtual-fields').slideUp();
        } else if (val === 'virtual') {
            $('#venue-fields').slideUp();
            $('#virtual-fields').slideDown();
        } else {
            // Hybrid
            $('#venue-fields').slideDown();
            $('#virtual-fields').slideDown();
        }
    });

    // 3. Media Uploader for Banner
    let mediaUploader;
    $('#ke-banner-uploader .ke-btn').on('click', function(e) {
        e.preventDefault();
        
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }
        
        mediaUploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose Event Banner',
            button: { text: 'Choose Image' },
            multiple: false
        });

        mediaUploader.on('select', function() {
            const attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#event_banner_id').val(attachment.id);
            
            const preview = $('#ke-banner-uploader .uploader-preview');
            let img = preview.find('img');
            if (img.length === 0) {
                img = $('<img>').appendTo(preview);
            }
            img.attr('src', attachment.url).show();
            $('#ke-banner-uploader .ke-btn').text('Change Image');
        });

        mediaUploader.open();
    });

    // 4. Dynamic Ticket Types
    let ticketIndex = 0;
    const $ticketContainer = $('#ke-ticket-types-container');
    const $addTicketBtn = $('#ke-add-ticket-type');

    $addTicketBtn.on('click', function() {
        const $empty = $ticketContainer.find('.ke-empty-state');
        if ($empty.length) $empty.remove();

        const html = `
            <div class="ke-ticket-card">
                <button type="button" class="btn-remove-ticket" title="Remove Ticket">&times;</button>
                <div class="form-group">
                    <label>Ticket Name</label>
                    <input type="text" name="tickets[${ticketIndex}][name]" placeholder="e.g. General Admission" required>
                </div>
                <div class="form-group">
                    <label>Price</label>
                    <input type="number" step="0.01" name="tickets[${ticketIndex}][price]" placeholder="0.00 (Free)">
                </div>
                <div class="form-group">
                    <label>Quantity Available</label>
                    <input type="number" name="tickets[${ticketIndex}][qty]" placeholder="Unlimited">
                </div>
            </div>
        `;
        $ticketContainer.append(html);
        ticketIndex++;
    });

    $ticketContainer.on('click', '.btn-remove-ticket', function() {
        $(this).closest('.ke-ticket-card').fadeOut(300, function() { 
            $(this).remove(); 
            if ($ticketContainer.children().length === 0) {
                $ticketContainer.append('<div class="ke-empty-state">No tickets added yet.</div>');
            }
        });
    });

    // Add a default ticket if none exist
    if ($ticketContainer.children('.ke-ticket-card').length === 0) {
        $addTicketBtn.click();
    }

    // 5. Form Submission (Save via REST API)
    $('#ke-builder-publish').on('click', function(e) {
        e.preventDefault();
        saveEvent('publish');
    });

    $('#ke-builder-save-draft').on('click', function(e) {
        e.preventDefault();
        saveEvent('draft');
    });

    function saveEvent(status) {
        const formData = new FormData(document.getElementById('ke-event-builder-form'));
        const eventData = Object.fromEntries(formData.entries());
        
        // Handle tinymce description if initialized
        if (typeof tinymce !== 'undefined' && tinymce.get('event_description')) {
            eventData.event_description = tinymce.get('event_description').getContent();
        }

        // Build structured tickets array
        eventData.tickets = [];
        $ticketContainer.find('.ke-ticket-card').each(function() {
            const name = $(this).find('input[name*="[name]"]').val();
            const price = $(this).find('input[name*="[price]"]').val();
            const qty = $(this).find('input[name*="[qty]"]').val();
            if (name) {
                eventData.tickets.push({ name, price, qty });
            }
        });
        
        // Get categories (array of checkboxes)
        const categories = [];
        $('input[name="event_categories[]"]:checked').each(function() {
            categories.push($(this).val());
        });
        eventData.event_categories = categories;

        eventData.post_status = status;

        const btn = status === 'publish' ? $('#ke-builder-publish') : $('#ke-builder-save-draft');
        const origText = btn.text();
        btn.prop('disabled', true).text('Saving...');

        $.ajax({
            url: keBuilderData.restUrl + 'events/save',
            type: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', keBuilderData.nonce);
            },
            data: JSON.stringify(eventData),
            contentType: 'application/json',
            success: function(response) {
                alert('Event saved successfully!');
                if (response.event_id && !$('#ke-event-builder-form input[name="event_id"]').val()) {
                    // Update form with new post ID
                    $('#ke-event-builder-form input[name="event_id"]').val(response.event_id);
                    $('.ke-builder-title h1').text('Edit Event');
                    
                    // Update URL to avoid duplicate creation on reload
                    window.history.replaceState({}, '', window.location.href + '&event_id=' + response.event_id);
                }
                btn.prop('disabled', false).text(origText);
                
                if (status === 'publish' && response.permalink) {
                    window.location.href = response.permalink;
                }
            },
            error: function(err) {
                console.error(err);
                alert('Error saving event: ' + (err.responseJSON ? err.responseJSON.message : 'Unknown error'));
                btn.prop('disabled', false).text(origText);
            }
        });
    }
});
