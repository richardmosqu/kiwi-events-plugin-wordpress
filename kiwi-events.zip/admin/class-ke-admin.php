<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Admin menu, page routing, and asset enqueueing
 */
class KE_Admin {

    public function init() {
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'current_screen', array( $this, 'redirect_to_custom_builder' ) );
    }

    /**
     * Register admin menu pages
     */
    public function register_menu() {
        // Main menu
        add_menu_page(
            'KiwiEvents',
            'KiwiEvents',
            'manage_kiwi_events',
            'kiwi-events',
            array( $this, 'render_dashboard_page' ),
            'dashicons-calendar-alt',
            26
        );

        // Dashboard submenu
        add_submenu_page(
            'kiwi-events',
            'Dashboard',
            'Dashboard',
            'manage_kiwi_events',
            'kiwi-events',
            array( $this, 'render_dashboard_page' )
        );

        // Events (CPT) — link to the CPT admin page
        add_submenu_page(
            'kiwi-events',
            'Events',
            'Events',
            'manage_kiwi_events',
            'edit.php?post_type=ke_event'
        );

        // Add New Event
        add_submenu_page(
            'kiwi-events',
            'Add New Event',
            'Add New Event',
            'manage_kiwi_events',
            'ke-event-builder',
            array( $this, 'render_event_builder' )
        );

        // Event Categories
        add_submenu_page(
            'kiwi-events',
            'Categories',
            'Categories',
            'manage_kiwi_events',
            'edit-tags.php?taxonomy=ke_event_category&post_type=ke_event'
        );

        // Organizers
        add_submenu_page(
            'kiwi-events',
            'Organizers',
            'Organizers',
            'manage_kiwi_events',
            'edit-tags.php?taxonomy=ke_organizer&post_type=ke_event'
        );

        // Tags
        add_submenu_page(
            'kiwi-events',
            'Tags',
            'Tags',
            'manage_kiwi_events',
            'edit-tags.php?taxonomy=ke_event_tag&post_type=ke_event'
        );

        // Attendees
        add_submenu_page(
            'kiwi-events',
            'Attendees',
            'Attendees',
            'manage_kiwi_events',
            'kiwi-events-attendees',
            array( $this, 'render_attendees_page' )
        );

        // Scanner shortcut
        add_submenu_page(
            'kiwi-events',
            'Ticket Scanner',
            'Scanner',
            'scan_ke_tickets',
            'kiwi-events-scanner',
            array( $this, 'render_scanner_link' )
        );
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_assets( $hook ) {
        // Only load on our plugin pages
        $plugin_pages = array(
            'toplevel_page_kiwi-events',
            'kiwievents_page_kiwi-events-attendees',
            'kiwievents_page_kiwi-events-scanner',
        );

        $is_ke_page = in_array( $hook, $plugin_pages )
                      || ( isset( $_GET['post_type'] ) && $_GET['post_type'] === 'ke_event' )
                      || ( get_post_type() === 'ke_event' );

        if ( ! $is_ke_page ) {
            return;
        }

        // Admin CSS
        wp_enqueue_style(
            'ke-admin-css',
            KE_PLUGIN_URL . 'admin/css/ke-admin.css',
            array(),
            KE_VERSION
        );

        // Dashboard-specific assets
        if ( $hook === 'toplevel_page_kiwi-events' ) {
            // Chart.js
            wp_enqueue_script(
                'chartjs',
                'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js',
                array(),
                '4.4.0',
                true
            );

            wp_enqueue_script(
                'ke-admin-dashboard',
                KE_PLUGIN_URL . 'admin/js/ke-admin-dashboard.js',
                array( 'jquery', 'chartjs' ),
                KE_VERSION,
                true
            );

            wp_localize_script( 'ke-admin-dashboard', 'keAdmin', array(
                'restUrl' => esc_url_raw( rest_url( 'ke/v1/' ) ),
                'nonce'   => wp_create_nonce( 'wp_rest' ),
            ) );
        }

        // General admin JS
        wp_enqueue_script(
            'ke-admin-js',
            KE_PLUGIN_URL . 'admin/js/ke-admin.js',
            array( 'jquery' ),
            KE_VERSION,
            true
        );

        wp_localize_script( 'ke-admin-js', 'keAdminData', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'restUrl' => esc_url_raw( rest_url( 'ke/v1/' ) ),
            'nonce'   => wp_create_nonce( 'wp_rest' ),
        ) );
    }

    /**
     * Render dashboard page
     */
    public function render_dashboard_page() {
        $dashboard = new KE_Admin_Dashboard();
        $dashboard->render();
    }

    /**
     * Render attendees page
     */
    public function render_attendees_page() {
        $attendees = new KE_Admin_Attendees();
        $attendees->render();
    }

    /**
     * Render scanner link page
     */
    public function render_scanner_link() {
        $scanner_url = home_url( '/kiwi-scanner/' );
        ?>
        <div class="wrap ke-wrap">
            <h1>🎟️ Ticket Scanner</h1>
            <div class="ke-scanner-card">
                <p>Open the ticket scanner on your mobile device to scan QR codes at the venue entrance.</p>
                <a href="<?php echo esc_url( $scanner_url ); ?>" target="_blank" class="button button-primary button-hero">
                    📱 Open Scanner
                </a>
                <p class="description" style="margin-top: 16px;">
                    Scanner URL: <code><?php echo esc_url( $scanner_url ); ?></code>
                </p>
            </div>
        </div>
        <?php
    }

    /**
     * Redirect standard WP editor to our custom builder
     */
    public function redirect_to_custom_builder() {
        $screen = get_current_screen();
        if ( ! $screen ) return;

        // Redirect 'post.php?action=edit&post=ID' for 'ke_event'
        if ( $screen->id === 'ke_event' && $screen->base === 'post' ) {
            $post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
            if ( $post_id ) {
                $url = admin_url( 'admin.php?page=ke-event-builder&event_id=' . $post_id );
                wp_redirect( $url );
                exit;
            }
        }
    }

    /**
     * Render the Event Builder View
     */
    public function render_event_builder() {
        require_once KE_PLUGIN_DIR . 'admin/views/event-builder.php';
    }
}
