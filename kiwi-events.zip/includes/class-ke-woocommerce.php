<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * WooCommerce integration for paid tickets
 */
class KE_WooCommerce {

    public function init() {
        // When a WooCommerce order is completed, generate tickets
        add_action( 'woocommerce_order_status_completed', array( $this, 'handle_order_completed' ) );
        add_action( 'woocommerce_order_status_refunded', array( $this, 'handle_order_refunded' ) );

        // Cart validation — enforce ticket limits
        add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'validate_add_to_cart' ), 10, 5 );

        // Display ticket info in cart/checkout
        add_filter( 'woocommerce_get_item_data', array( $this, 'display_cart_item_data' ), 10, 2 );

        // Save custom data to order item meta
        add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'save_order_item_meta' ), 10, 4 );
    }

    /**
     * Add ticket to WooCommerce cart
     *
     * @param int    $event_id       Event post ID
     * @param int    $ticket_type_id Ticket type ID
     * @param int    $quantity       Number of tickets
     * @param string $attendee_name  Buyer name
     * @param string $attendee_email Buyer email
     * @return bool|WP_Error
     */
    public function add_to_cart( $event_id, $ticket_type_id, $quantity, $attendee_name, $attendee_email ) {
        $ticket_types = new KE_Ticket_Types();
        $ticket_type  = $ticket_types->get( $ticket_type_id );

        if ( ! $ticket_type ) {
            return new WP_Error( 'invalid_ticket_type', 'Ticket type not found.' );
        }

        // Check availability
        $remaining = $ticket_types->get_remaining( $ticket_type_id );
        if ( $quantity > $remaining ) {
            return new WP_Error( 'sold_out', 'Not enough tickets available.' );
        }

        // Get or create the WC product for this ticket type
        $product_id = $this->get_or_create_product( $ticket_type, $event_id );

        if ( is_wp_error( $product_id ) ) {
            return $product_id;
        }

        // Add to cart with custom data
        $cart_item_data = array(
            'ke_event_id'       => $event_id,
            'ke_ticket_type_id' => $ticket_type_id,
            'ke_attendee_name'  => $attendee_name,
            'ke_attendee_email' => $attendee_email,
        );

        $cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity, 0, array(), $cart_item_data );

        if ( ! $cart_item_key ) {
            return new WP_Error( 'cart_error', 'Could not add to cart.' );
        }

        return true;
    }

    /**
     * Get or create a virtual WooCommerce product for a ticket type
     */
    private function get_or_create_product( $ticket_type, $event_id ) {
        // Check if product already exists
        $existing_product_id = get_post_meta( $event_id, '_ke_wc_product_' . $ticket_type->id, true );

        if ( $existing_product_id && get_post_status( $existing_product_id ) === 'publish' ) {
            // Update price if changed
            $product = wc_get_product( $existing_product_id );
            if ( $product && floatval( $product->get_price() ) !== floatval( $ticket_type->price ) ) {
                $product->set_price( $ticket_type->price );
                $product->set_regular_price( $ticket_type->price );
                $product->save();
            }
            return $existing_product_id;
        }

        // Create virtual product
        $event_title = get_the_title( $event_id );
        $product = new WC_Product_Simple();
        $product->set_name( $event_title . ' — ' . $ticket_type->name );
        $product->set_status( 'publish' );
        $product->set_catalog_visibility( 'hidden' );
        $product->set_price( $ticket_type->price );
        $product->set_regular_price( $ticket_type->price );
        $product->set_virtual( true );
        $product->set_sold_individually( false );
        $product->set_manage_stock( false );
        $product->set_description( 'Ticket for ' . $event_title );
        $product->set_short_description( $ticket_type->name . ' — ' . $event_title );

        $product_id = $product->save();

        if ( ! $product_id ) {
            return new WP_Error( 'product_creation_failed', 'Could not create WooCommerce product.' );
        }

        // Store the mapping
        update_post_meta( $event_id, '_ke_wc_product_' . $ticket_type->id, $product_id );
        update_post_meta( $product_id, '_ke_event_id', $event_id );
        update_post_meta( $product_id, '_ke_ticket_type_id', $ticket_type->id );

        return $product_id;
    }

    /**
     * Validate adding to cart — enforce ticket limits
     */
    public function validate_add_to_cart( $passed, $product_id, $quantity, $variation_id = 0, $cart_item_data = array() ) {
        if ( empty( $cart_item_data['ke_event_id'] ) ) {
            return $passed;
        }

        $orders = new KE_Orders();
        $can = $orders->can_purchase(
            $cart_item_data['ke_event_id'],
            $cart_item_data['ke_attendee_email'] ?? '',
            $quantity
        );

        if ( is_wp_error( $can ) ) {
            wc_add_notice( $can->get_error_message(), 'error' );
            return false;
        }

        return $passed;
    }

    /**
     * Display event/ticket info in cart
     */
    public function display_cart_item_data( $item_data, $cart_item_data ) {
        if ( ! empty( $cart_item_data['ke_event_id'] ) ) {
            $item_data[] = array(
                'key'   => 'Event',
                'value' => get_the_title( $cart_item_data['ke_event_id'] ),
            );
        }
        if ( ! empty( $cart_item_data['ke_attendee_name'] ) ) {
            $item_data[] = array(
                'key'   => 'Attendee',
                'value' => $cart_item_data['ke_attendee_name'],
            );
        }
        return $item_data;
    }

    /**
     * Save ticket metadata to WC order item
     */
    public function save_order_item_meta( $item, $cart_item_key, $values, $order ) {
        $ke_fields = array( 'ke_event_id', 'ke_ticket_type_id', 'ke_attendee_name', 'ke_attendee_email' );
        foreach ( $ke_fields as $field ) {
            if ( ! empty( $values[ $field ] ) ) {
                $item->add_meta_data( $field, $values[ $field ], true );
            }
        }
    }

    /**
     * Handle completed WooCommerce order — generate tickets
     */
    public function handle_order_completed( $wc_order_id ) {
        $wc_order = wc_get_order( $wc_order_id );

        if ( ! $wc_order ) {
            return;
        }

        // Check if we already processed this order
        if ( $wc_order->get_meta( '_ke_tickets_generated' ) ) {
            return;
        }

        $orders_handler  = new KE_Orders();
        $tickets_handler = new KE_Tickets();
        $email_handler   = new KE_Email();

        foreach ( $wc_order->get_items() as $item ) {
            $event_id       = $item->get_meta( 'ke_event_id' );
            $ticket_type_id = $item->get_meta( 'ke_ticket_type_id' );
            $attendee_name  = $item->get_meta( 'ke_attendee_name' );
            $attendee_email = $item->get_meta( 'ke_attendee_email' );

            if ( ! $event_id || ! $ticket_type_id ) {
                continue;
            }

            $quantity = $item->get_quantity();

            // Create KE order
            $order_result = $orders_handler->create( array(
                'event_id'        => $event_id,
                'user_id'         => $wc_order->get_user_id(),
                'buyer_name'      => $attendee_name ?: $wc_order->get_billing_first_name() . ' ' . $wc_order->get_billing_last_name(),
                'buyer_email'     => $attendee_email ?: $wc_order->get_billing_email(),
                'total_amount'    => $item->get_total(),
                'ticket_quantity' => $quantity,
                'payment_method'  => 'woocommerce',
                'payment_status'  => 'completed',
                'wc_order_id'     => $wc_order_id,
            ) );

            if ( is_wp_error( $order_result ) ) {
                continue;
            }

            // Generate tickets
            $tickets_handler->generate(
                $order_result['order_id'],
                $event_id,
                $ticket_type_id,
                $quantity,
                $attendee_name ?: $wc_order->get_billing_first_name() . ' ' . $wc_order->get_billing_last_name(),
                $attendee_email ?: $wc_order->get_billing_email()
            );

            // Send ticket email
            $email_handler->send_ticket_email( $order_result['order_id'] );
        }

        // Mark as processed
        $wc_order->update_meta_data( '_ke_tickets_generated', true );
        $wc_order->save();
    }

    /**
     * Handle refunded WooCommerce order — cancel tickets
     */
    public function handle_order_refunded( $wc_order_id ) {
        global $wpdb;

        $orders_table  = $wpdb->prefix . 'ke_orders';
        $tickets_table = $wpdb->prefix . 'ke_tickets';

        // Find KE orders linked to this WC order
        $ke_orders = $wpdb->get_results( $wpdb->prepare(
            "SELECT id FROM {$orders_table} WHERE wc_order_id = %d",
            $wc_order_id
        ) );

        $tickets_handler = new KE_Tickets();
        $orders_handler  = new KE_Orders();

        foreach ( $ke_orders as $ke_order ) {
            // Cancel all tickets
            $tickets = $wpdb->get_results( $wpdb->prepare(
                "SELECT id FROM {$tickets_table} WHERE order_id = %d AND status = 'valid'",
                $ke_order->id
            ) );

            foreach ( $tickets as $ticket ) {
                $tickets_handler->cancel( $ticket->id );
            }

            // Update order status
            $orders_handler->update_status( $ke_order->id, 'refunded' );
        }
    }
}
