<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Main orchestrator class for KiwiEvents
 */
class Kiwi_Events {

    /** @var KE_Post_Types */
    private $post_types;

    /** @var KE_Admin */
    private $admin;

    /** @var KE_Public */
    private $public_facing;

    /** @var KE_Rest_API */
    private $rest_api;

    /** @var KE_WooCommerce */
    private $woocommerce;

    /** @var KE_Scanner */
    private $scanner;

    /**
     * Initialize all components
     */
    public function run() {
        // Core
        $this->post_types = new KE_Post_Types();
        $this->post_types->init();

        // Admin
        if ( is_admin() ) {
            $this->admin = new KE_Admin();
            $this->admin->init();
        }

        // Public
        $this->public_facing = new KE_Public();
        $this->public_facing->init();

        // REST API
        $this->rest_api = new KE_Rest_API();
        add_action( 'rest_api_init', array( $this->rest_api, 'register_routes' ) );

        // WooCommerce integration (only if WC is active)
        if ( class_exists( 'WooCommerce' ) ) {
            $this->woocommerce = new KE_WooCommerce();
            $this->woocommerce->init();
        }

        // Scanner
        $this->scanner = new KE_Scanner();
        $this->scanner->init();
    }
}
