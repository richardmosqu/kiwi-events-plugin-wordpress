<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Email service — sends ticket emails with PDF attachments
 */
class KE_Email {

    /**
     * Send ticket email after order completion
     *
     * @param int $order_id The order ID
     * @return bool|WP_Error
     */
    public function send_ticket_email( $order_id ) {
        $orders_handler  = new KE_Orders();
        $tickets_handler = new KE_Tickets();
        $pdf_generator   = new KE_PDF_Generator();

        $order = $orders_handler->get( $order_id );
        if ( ! $order ) {
            return new WP_Error( 'order_not_found', 'Order not found.' );
        }

        // Get tickets for this order
        $tickets = $tickets_handler->get_by_order( $order_id );
        if ( empty( $tickets ) ) {
            return new WP_Error( 'no_tickets', 'No tickets found for this order.' );
        }

        // Get event info
        $event_title = get_the_title( $order->event_id );
        $event_date  = get_post_meta( $order->event_id, '_ke_event_date_start', true );
        $event_venue = get_post_meta( $order->event_id, '_ke_event_venue', true );

        // Generate PDFs and collect paths
        $attachments = array();
        foreach ( $tickets as $ticket ) {
            if ( empty( $ticket->pdf_path ) || ! file_exists( $ticket->pdf_path ) ) {
                $pdf_path = $pdf_generator->generate( $ticket );
                if ( ! is_wp_error( $pdf_path ) ) {
                    $attachments[] = $pdf_path;
                }
            } else {
                $attachments[] = $ticket->pdf_path;
            }
        }

        // Build email
        $to      = $order->buyer_email;
        $subject = '🎟️ Your tickets for ' . $event_title . ' — Order #' . $order->order_number;

        // Format date
        $formatted_date = $event_date ? date( 'l, F j, Y \a\t g:i A', strtotime( $event_date ) ) : 'TBA';

        // Build HTML email body
        $body = $this->get_email_html( array(
            'buyer_name'   => $order->buyer_name,
            'event_title'  => $event_title,
            'event_date'   => $formatted_date,
            'event_venue'  => $event_venue,
            'order_number' => $order->order_number,
            'total_amount' => $order->total_amount,
            'ticket_count' => count( $tickets ),
            'tickets'      => $tickets,
        ) );

        // Email headers
        $from_name  = get_option( 'ke_email_from_name', get_bloginfo( 'name' ) );
        $from_email = get_option( 'ke_email_from_address', get_bloginfo( 'admin_email' ) );

        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            "From: {$from_name} <{$from_email}>",
        );

        // Send
        $sent = wp_mail( $to, $subject, $body, $headers, $attachments );

        if ( ! $sent ) {
            return new WP_Error( 'email_failed', 'Failed to send ticket email.' );
        }

        return true;
    }

    /**
     * Build the HTML email template
     */
    private function get_email_html( $data ) {
        ob_start();
        ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background-color:#f4f4f8;font-family:Arial,Helvetica,sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f8;padding:30px 0;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="background-color:#181826;border-radius:16px;overflow:hidden;">
                    <!-- Header -->
                    <tr>
                        <td style="background:linear-gradient(135deg,#6bcb77,#4aa356);padding:30px 40px;">
                            <h1 style="margin:0;color:#fff;font-size:22px;font-weight:700;">🥝 KiwiEvents</h1>
                            <p style="margin:8px 0 0;color:rgba(255,255,255,0.85);font-size:14px;">Your tickets are ready!</p>
                        </td>
                    </tr>

                    <!-- Body -->
                    <tr>
                        <td style="padding:40px;">
                            <p style="color:#e0e0e8;font-size:16px;margin:0 0 20px;">
                                Hi <strong style="color:#fff;"><?php echo esc_html( $data['buyer_name'] ); ?></strong>,
                            </p>
                            <p style="color:#b0b0c0;font-size:14px;margin:0 0 30px;line-height:1.6;">
                                Thank you for your order! Your tickets are attached to this email as PDF files. You can also show the QR code at the venue entrance.
                            </p>

                            <!-- Event Card -->
                            <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#22223a;border-radius:12px;border:1px solid #2a2a45;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h2 style="margin:0 0 16px;color:#fff;font-size:20px;"><?php echo esc_html( $data['event_title'] ); ?></h2>
                                        <table cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td style="padding:4px 0;color:#8888a0;font-size:13px;">📅&nbsp;&nbsp;<?php echo esc_html( $data['event_date'] ); ?></td>
                                            </tr>
                                            <?php if ( $data['event_venue'] ) : ?>
                                            <tr>
                                                <td style="padding:4px 0;color:#8888a0;font-size:13px;">📍&nbsp;&nbsp;<?php echo esc_html( $data['event_venue'] ); ?></td>
                                            </tr>
                                            <?php endif; ?>
                                        </table>
                                    </td>
                                </tr>
                            </table>

                            <!-- Order Summary -->
                            <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:24px;background-color:#22223a;border-radius:12px;border:1px solid #2a2a45;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 16px;color:#6bcb77;font-size:14px;text-transform:uppercase;letter-spacing:1px;">Order Summary</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td style="padding:6px 0;color:#8888a0;font-size:13px;">Order Number</td>
                                                <td style="padding:6px 0;color:#fff;font-size:13px;text-align:right;font-weight:600;"><?php echo esc_html( $data['order_number'] ); ?></td>
                                            </tr>
                                            <tr>
                                                <td style="padding:6px 0;color:#8888a0;font-size:13px;">Tickets</td>
                                                <td style="padding:6px 0;color:#fff;font-size:13px;text-align:right;font-weight:600;"><?php echo intval( $data['ticket_count'] ); ?></td>
                                            </tr>
                                            <tr>
                                                <td style="padding:6px 0;color:#8888a0;font-size:13px;border-top:1px solid #2a2a45;padding-top:12px;">Total</td>
                                                <td style="padding:6px 0;color:#6bcb77;font-size:18px;text-align:right;font-weight:700;border-top:1px solid #2a2a45;padding-top:12px;">
                                                    <?php echo $data['total_amount'] > 0 ? '$' . number_format( $data['total_amount'], 2 ) : 'FREE'; ?>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>

                            <!-- Instructions -->
                            <p style="color:#8888a0;font-size:12px;margin:30px 0 0;line-height:1.6;">
                                📎 Your ticket PDF(s) are attached to this email.<br>
                                📱 Present the QR code from your ticket at the venue entrance.<br>
                                ❌ Each ticket can only be used once.
                            </p>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="padding:20px 40px;border-top:1px solid #2a2a45;">
                            <p style="margin:0;color:#5a5a70;font-size:11px;text-align:center;">
                                Powered by KiwiEvents &bull; <?php echo esc_html( get_bloginfo( 'name' ) ); ?> &bull; <?php echo esc_url( home_url() ); ?>
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        <?php
        return ob_get_clean();
    }
}
