<?php
if ( ! defined( 'ABSPATH' ) ) exit;

use chillerlan\QRCode\{QRCode, QROptions};

/**
 * QR Code generator wrapper using chillerlan/php-qrcode
 */
class KE_QR_Generator {

    private $upload_dir;

    public function __construct() {
        $upload = wp_upload_dir();
        $this->upload_dir = $upload['basedir'] . '/kiwi-events/qrcodes/';

        // Create directory if needed
        if ( ! is_dir( $this->upload_dir ) ) {
            wp_mkdir_p( $this->upload_dir );
        }
    }

    /**
     * Generate a QR code image for a ticket code
     *
     * @param string $ticket_code The unique ticket code
     * @return string|WP_Error File path on success, WP_Error on failure
     */
    public function generate( $ticket_code ) {
        // Build the validation URL
        $verify_url = home_url( '/ke-verify/' . $ticket_code );

        // Set QR options
        try {
            $options = new QROptions([
                'version'         => 5,
                'outputType'      => QRCode::OUTPUT_IMAGE_PNG,
                'eccLevel'        => QRCode::ECC_M,
                'scale'           => 10,
                'imageBase64'     => false,
                'addQuietzone'    => true,
                'quietzoneSize'   => 2,
                'imageTransparent' => false,
            ]);

            $qrcode = new QRCode( $options );
            $image_data = $qrcode->render( $verify_url );

            // Save to file
            $filename = $ticket_code . '.png';
            $filepath = $this->upload_dir . $filename;

            file_put_contents( $filepath, $image_data );

            if ( ! file_exists( $filepath ) ) {
                return new WP_Error( 'qr_save_failed', 'Failed to save QR code image.' );
            }

            return $filepath;

        } catch ( \Exception $e ) {
            return new WP_Error( 'qr_generation_failed', 'QR code generation failed: ' . $e->getMessage() );
        }
    }

    /**
     * Get the URL for a QR code image
     */
    public function get_url( $ticket_code ) {
        $upload = wp_upload_dir();
        return $upload['baseurl'] . '/kiwi-events/qrcodes/' . $ticket_code . '.png';
    }

    /**
     * Delete a QR code file
     */
    public function delete( $ticket_code ) {
        $filepath = $this->upload_dir . $ticket_code . '.png';
        if ( file_exists( $filepath ) ) {
            unlink( $filepath );
        }
    }
}
