/**
 * KiwiEvents — Checkout JS
 * Bottom-sheet modal flow: Ticket Card → Quantity → Details → Submit
 */
(function($) {
    'use strict';

    // ─── State ──────────────────────────────────────────
    let currentTicket = null; // { id, name, price, remaining, min, max }
    let qty = 1;

    const $overlay = $('#ke-sheet-overlay');
    const $sheet   = $('#ke-checkout-sheet');
    const $stepQty = $('#ke-sheet-step-qty');
    const $stepDetails = $('#ke-sheet-step-details');

    // ─── Open Sheet (when ticket card is clicked) ───────
    $(document).on('click', '.ke-ticket-card:not(.ke-ticket-sold-out)', function() {
        const $card = $(this);

        currentTicket = {
            id:        parseInt($card.data('ticket-type-id')),
            name:      $card.data('name'),
            price:     parseFloat($card.data('price')) || 0,
            remaining: parseInt($card.data('remaining')) || 9999,
            min:       parseInt($card.data('min')) || 1,
            max:       parseInt($card.data('max')) || 10,
        };

        // Clamp max to remaining
        currentTicket.max = Math.min(currentTicket.max, currentTicket.remaining);

        // Reset to minimum
        qty = currentTicket.min;

        // Populate sheet
        $('#ke-sheet-ticket-name').text(currentTicket.name);
        updateSheetDisplay();

        // Show step 1
        $stepQty.show();
        $stepDetails.hide();
        $('#ke-sheet-message').hide();

        // Open
        openSheet();
    });

    // ─── Close on overlay click ─────────────────────────
    $overlay.on('click', closeSheet);

    // ─── Quantity Controls ──────────────────────────────
    $('#ke-sheet-minus').on('click', function() {
        if (qty > currentTicket.min) {
            qty--;
            updateSheetDisplay();
        }
    });

    $('#ke-sheet-plus').on('click', function() {
        if (qty < currentTicket.max) {
            qty++;
            updateSheetDisplay();
        }
    });

    // ─── Continue to details ────────────────────────────
    $('#ke-sheet-continue').on('click', function() {
        $stepQty.slideUp(200);
        setTimeout(function() {
            $stepDetails.slideDown(200);
        }, 200);
    });

    // ─── Submit checkout ────────────────────────────────
    $('#ke-checkout-form-sheet').on('submit', function(e) {
        e.preventDefault();

        const name  = $('#ke-sheet-name').val().trim();
        const email = $('#ke-sheet-email').val().trim();
        const $msg  = $('#ke-sheet-message');
        const $btn  = $('#ke-sheet-submit');

        if (!name || !email) {
            showMsg($msg, 'Please fill in your name and email.', 'error');
            return;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            showMsg($msg, 'Please enter a valid email address.', 'error');
            return;
        }

        $btn.prop('disabled', true).html('<span class="ke-spinner-inline"></span> Processing...');
        $msg.hide();

        const payload = {
            event_id:       parseInt($sheet.data('event-id')),
            ticket_type_id: currentTicket.id,
            quantity:        qty,
            name:            name,
            email:           email,
        };

        $.ajax({
            url: kePublic.restUrl + 'checkout',
            method: 'POST',
            data: JSON.stringify(payload),
            contentType: 'application/json',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', kePublic.nonce);
            },
            success: function(response) {
                if (response.payment_type === 'woocommerce' && response.redirect) {
                    window.location.href = response.redirect;
                    return;
                }

                showMsg($msg, '🎉 ' + response.message, 'success');
                $btn.html('✅ Tickets Sent!');

                setTimeout(function() {
                    closeSheet();
                    // Reset form
                    $('#ke-sheet-name').val('');
                    $('#ke-sheet-email').val('');
                    $btn.prop('disabled', false).html('🎟️ Get Tickets');
                    $msg.hide();
                }, 3000);
            },
            error: function(xhr) {
                const msg = xhr.responseJSON?.message || 'Something went wrong. Please try again.';
                showMsg($msg, msg, 'error');
                $btn.prop('disabled', false).html('🎟️ Get Tickets');
            }
        });
    });

    // ─── Helpers ────────────────────────────────────────
    function openSheet() {
        $overlay.addClass('active');
        $sheet.addClass('active');
        $('body').css('overflow', 'hidden');
    }

    function closeSheet() {
        $overlay.removeClass('active');
        $sheet.removeClass('active');
        $('body').css('overflow', '');
    }

    function updateSheetDisplay() {
        const total = currentTicket.price * qty;
        const isFree = currentTicket.price === 0;

        $('#ke-sheet-qty-val').text(qty);

        // Breakdown
        if (isFree) {
            $('#ke-breakdown-label').text('Free × ' + qty + (qty === 1 ? ' ticket' : ' tickets'));
            $('#ke-breakdown-subtotal').text('Free');
            $('#ke-sheet-total-val, #ke-sheet-total-val-2').text('Free');
        } else {
            const priceStr = '$' + currentTicket.price.toFixed(2);
            $('#ke-breakdown-label').text(priceStr + ' × ' + qty + (qty === 1 ? ' ticket' : ' tickets'));
            $('#ke-breakdown-subtotal').text('$' + total.toFixed(2));
            $('#ke-sheet-total-val, #ke-sheet-total-val-2').text('$' + total.toFixed(2));
        }

        // Dim buttons at limits
        $('#ke-sheet-minus').css('opacity', qty <= currentTicket.min ? 0.3 : 1);
        $('#ke-sheet-plus').css('opacity', qty >= currentTicket.max ? 0.3 : 1);
    }

    function showMsg($el, text, type) {
        $el.html(text)
           .removeClass('ke-msg-success ke-msg-error')
           .addClass('ke-sheet-form-message ke-msg-' + type)
           .show();
    }

    // ─── Escape key to close ────────────────────────────
    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') closeSheet();
    });

})(jQuery);
