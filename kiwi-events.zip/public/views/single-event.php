<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<?php
get_header();

$event_id    = $post->ID;

// Fetch tickets
$ticket_types = new KE_Ticket_Types();
$types = $ticket_types->get_available( $event_id );
$date_start  = get_post_meta( $event_id, '_ke_event_date_start', true );
$date_end    = get_post_meta( $event_id, '_ke_event_date_end', true );
$timezone    = get_post_meta( $event_id, '_ke_event_timezone', true ) ?: wp_timezone_string();
$venue       = get_post_meta( $event_id, '_ke_event_venue', true );
$address     = get_post_meta( $event_id, '_ke_event_address', true );
$location_type = get_post_meta( $event_id, '_ke_event_location_type', true ) ?: 'venue';
$virtual_url = get_post_meta( $event_id, '_ke_event_virtual_url', true );
$status      = get_post_meta( $event_id, '_ke_event_status', true ) ?: 'active';
$thumbnail   = get_the_post_thumbnail_url( $event_id, 'large' );

// Get organizer
$organizers = wp_get_post_terms( $event_id, 'ke_organizer', array( 'fields' => 'names' ) );
$organizer_name = ! empty( $organizers ) ? $organizers[0] : '';

// Format date
$tz_abbr = '';
if ( $date_start ) {
    try {
        $dt = new DateTime( $date_start, new DateTimeZone( $timezone ) );
        $formatted_day  = $dt->format( 'l, j M' );
        $formatted_time = $dt->format( 'g:i A' );
        $tz_abbr = $dt->format( 'T' );
    } catch ( Exception $e ) {
        $formatted_day  = date( 'l, j M', strtotime( $date_start ) );
        $formatted_time = date( 'g:i A', strtotime( $date_start ) );
    }
} else {
    $formatted_day  = 'Date TBA';
    $formatted_time = '';
}

// Location text
$location_text = $venue ?: 'Location TBA';
$location_sub  = $address ?: '';
if ( $location_type === 'virtual' ) {
    $location_text = 'Online Event';
    $location_sub  = '';
} elseif ( $location_type === 'hybrid' ) {
    $location_sub  = $address ? $address . ' + Online' : 'In-person + Online';
}
?>

<div class="ke-event-page ke-event-page-breakout">
    <!-- ═══════════════ HERO SECTION ═══════════════ -->
    <div class="ke-hero">
        <div class="ke-hero-bg">
            <?php if ( $thumbnail ) : ?>
                <div class="ke-hero-bg-img" style="background-image: url('<?php echo esc_url( $thumbnail ); ?>');"></div>
            <?php endif; ?>
            <div class="ke-hero-bg-overlay"></div>
        </div>

        <div class="ke-hero-content">
            <div class="ke-hero-flyer">
                <?php if ( $thumbnail ) : ?>
                    <img src="<?php echo esc_url( $thumbnail ); ?>" alt="<?php echo esc_attr( $post->post_title ); ?>" class="ke-hero-flyer-img">
                <?php else : ?>
                    <div class="ke-hero-flyer-placeholder">📅</div>
                <?php endif; ?>
            </div>

            <div class="ke-hero-info">
                <?php if ( $organizer_name ) : ?>
                    <div class="ke-hero-organizer">
                        <span class="ke-organizer-badge">🎪</span>
                        <span>by <strong><?php echo esc_html( $organizer_name ); ?></strong></span>
                    </div>
                <?php endif; ?>

                <h1 class="ke-hero-title"><?php echo esc_html( $post->post_title ); ?></h1>

                <div class="ke-hero-meta">
                    <div class="ke-hero-meta-item">
                        <span class="ke-hero-meta-icon">📅</span>
                        <div>
                            <div class="ke-hero-meta-primary"><?php echo esc_html( $formatted_day ); ?></div>
                            <?php if ( $formatted_time ) : ?>
                                <div class="ke-hero-meta-secondary"><?php echo esc_html( $formatted_time . ' ' . $tz_abbr ); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="ke-hero-meta-item">
                        <span class="ke-hero-meta-icon"><?php echo $location_type === 'virtual' ? '💻' : '📍'; ?></span>
                        <div>
                            <div class="ke-hero-meta-primary"><?php echo esc_html( $location_text ); ?></div>
                            <?php if ( $location_sub ) : ?>
                                <div class="ke-hero-meta-secondary"><?php echo esc_html( $location_sub ); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- CTA Button -->
        <?php if ( $status === 'active' && ! empty( $types ) ) : ?>
            <div class="ke-hero-cta">
                <button type="button" class="ke-cta-btn" id="ke-scroll-to-tickets">
                    Get Tickets
                </button>
            </div>
        <?php endif; ?>
    </div>

    <!-- ═══════════════ ABOUT SECTION ═══════════════ -->
    <?php if ( $post->post_content ) : ?>
        <div class="ke-section">
            <h2 class="ke-section-title">About</h2>
            <div class="ke-about-content">
                <?php echo wp_kses_post( wpautop( $post->post_content ) ); ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- ═══════════════ TICKETS SECTION ═══════════════ -->
    <?php if ( ! empty( $types ) && $status === 'active' ) : ?>
        <div class="ke-section" id="ke-tickets-section">
            <h2 class="ke-section-title">Tickets</h2>

            <div class="ke-ticket-cards">
                <?php foreach ( $types as $type ) :
                    $remaining   = max( 0, $type->quantity_total - $type->quantity_sold );
                    $is_sold_out = ( $type->capacity_type ?? 'limited' ) !== 'unlimited' && $remaining <= 0;
                    $is_free     = floatval( $type->price ) == 0;
                    $show_remaining = ( $type->show_remaining ?? 'yes' ) === 'yes';
                ?>
                    <button type="button"
                            class="ke-ticket-card <?php echo $is_sold_out ? 'ke-ticket-sold-out' : ''; ?>"
                            data-ticket-type-id="<?php echo esc_attr( $type->id ); ?>"
                            data-name="<?php echo esc_attr( $type->name ); ?>"
                            data-price="<?php echo esc_attr( $type->price ); ?>"
                            data-remaining="<?php echo esc_attr( $remaining ); ?>"
                            data-min="<?php echo esc_attr( $type->min_per_order ?? 1 ); ?>"
                            data-max="<?php echo esc_attr( $type->max_per_order ?? 10 ); ?>"
                            data-description="<?php echo esc_attr( $type->description ?? '' ); ?>"
                            <?php echo $is_sold_out ? 'disabled' : ''; ?>>

                        <div class="ke-ticket-card-left">
                            <span class="ke-ticket-card-name"><?php echo esc_html( $type->name ); ?></span>
                            <?php if ( $type->description ) : ?>
                                <span class="ke-ticket-card-desc"><?php echo esc_html( $type->description ); ?></span>
                            <?php endif; ?>
                            <?php if ( $show_remaining && ! $is_sold_out && ( $type->capacity_type ?? 'limited' ) !== 'unlimited' ) : ?>
                                <?php if ( $remaining <= 20 ) : ?>
                                    <span class="ke-ticket-card-remaining"><?php echo $remaining; ?> left</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <div class="ke-ticket-card-right">
                            <?php if ( $is_sold_out ) : ?>
                                <span class="ke-ticket-card-soldout-badge">Sold Out</span>
                            <?php else : ?>
                                <span class="ke-ticket-card-price">
                                    <?php echo $is_free ? 'Free' : '$' . number_format( $type->price, 2 ); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </button>
                <?php endforeach; ?>
            </div>
        </div>
    <?php elseif ( $status !== 'active' ) : ?>
        <div class="ke-section">
            <div class="ke-status-banner ke-status-<?php echo esc_attr( $status ); ?>">
                This event is currently <?php echo esc_html( $status ); ?>.
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- ═══════════════ BOTTOM SHEET CHECKOUT ═══════════════ -->
<div class="ke-sheet-overlay" id="ke-sheet-overlay"></div>
<div class="ke-sheet" id="ke-checkout-sheet" data-event-id="<?php echo esc_attr( $event_id ); ?>">
    <div class="ke-sheet-handle"></div>

    <!-- Step 1: Quantity -->
    <div class="ke-sheet-step" id="ke-sheet-step-qty">
        <div class="ke-sheet-qty-header">
            <div class="ke-sheet-qty-info">
                <span class="ke-sheet-qty-count" id="ke-sheet-qty-val">1</span>
                <span class="ke-sheet-qty-sep">×</span>
                <span class="ke-sheet-qty-name" id="ke-sheet-ticket-name"></span>
            </div>
            <div class="ke-sheet-qty-controls">
                <button type="button" class="ke-sheet-qty-btn" id="ke-sheet-minus">−</button>
                <button type="button" class="ke-sheet-qty-btn" id="ke-sheet-plus">+</button>
            </div>
        </div>

        <div class="ke-sheet-breakdown">
            <div class="ke-sheet-breakdown-row">
                <span id="ke-breakdown-label">$0 × 1 ticket</span>
                <span id="ke-breakdown-subtotal">$0</span>
            </div>
            <div class="ke-sheet-breakdown-row ke-sheet-total">
                <span>Total (USD)</span>
                <strong id="ke-sheet-total-val">$0.00</strong>
            </div>
        </div>

        <button type="button" class="ke-sheet-continue-btn" id="ke-sheet-continue">
            Continue
        </button>
    </div>

    <!-- Step 2: Details -->
    <div class="ke-sheet-step" id="ke-sheet-step-details" style="display:none;">
        <h3 class="ke-sheet-details-title">Your Details</h3>
        <div class="ke-sheet-form-message" id="ke-sheet-message" style="display:none;"></div>
        <form id="ke-checkout-form-sheet">
            <div class="ke-sheet-field">
                <input type="text" id="ke-sheet-name" placeholder="Full Name" required>
            </div>
            <div class="ke-sheet-field">
                <input type="email" id="ke-sheet-email" placeholder="Email Address" required>
            </div>

            <div class="ke-sheet-breakdown" style="margin-top:16px;">
                <div class="ke-sheet-breakdown-row ke-sheet-total">
                    <span>Total</span>
                    <strong id="ke-sheet-total-val-2">$0.00</strong>
                </div>
            </div>

            <button type="submit" class="ke-sheet-continue-btn" id="ke-sheet-submit">
                🎟️ Get Tickets
            </button>
        </form>
        <p class="ke-sheet-terms">By continuing you agree to our Terms of Service and Privacy Policy</p>
    </div>
</div>

<script>
document.getElementById('ke-scroll-to-tickets')?.addEventListener('click', function() {
    document.getElementById('ke-tickets-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
});
</script>

<?php get_footer(); ?>
