<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Public-facing functionality — shortcodes and frontend assets
 */
class KE_Public {

    public function init() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );

        // Register shortcodes
        add_shortcode( 'kiwi_events', array( $this, 'shortcode_events' ) );
        add_shortcode( 'kiwi_event', array( $this, 'shortcode_single_event' ) );
        add_shortcode( 'kiwi_checkout', array( $this, 'shortcode_checkout' ) );

        // Override the entire template for single ke_event posts
        add_filter( 'single_template', array( $this, 'override_single_template' ) );
    }

    /**
     * Enqueue public CSS and JS
     */
    public function enqueue_assets() {
        wp_enqueue_style(
            'ke-public-css',
            KE_PLUGIN_URL . 'public/css/ke-public.css',
            array(),
            KE_VERSION
        );

        wp_enqueue_script(
            'ke-checkout-js',
            KE_PLUGIN_URL . 'public/js/ke-checkout.js',
            array( 'jquery' ),
            KE_VERSION,
            true
        );

        wp_localize_script( 'ke-checkout-js', 'kePublic', array(
            'restUrl' => esc_url_raw( rest_url( 'ke/v1/' ) ),
            'nonce'   => wp_create_nonce( 'wp_rest' ),
            'homeUrl' => home_url(),
        ) );
    }

    /**
     * [kiwi_events] — Event listing/archive
     */
    public function shortcode_events( $atts ) {
        $atts = shortcode_atts( array(
            'limit'    => 12,
            'category' => '',
            'columns'  => 3,
        ), $atts );

        $args = array(
            'post_type'      => 'ke_event',
            'post_status'    => 'publish',
            'posts_per_page' => intval( $atts['limit'] ),
            'orderby'        => 'meta_value',
            'meta_key'       => '_ke_event_date_start',
            'order'          => 'ASC',
            'meta_query'     => array(
                array(
                    'key'     => '_ke_event_status',
                    'value'   => 'active',
                    'compare' => '=',
                ),
            ),
        );

        if ( $atts['category'] ) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'ke_event_category',
                    'field'    => 'slug',
                    'terms'    => explode( ',', $atts['category'] ),
                ),
            );
        }

        $query = new WP_Query( $args );

        ob_start();
        include KE_PLUGIN_DIR . 'public/views/event-archive.php';
        return ob_get_clean();
    }

    /**
     * [kiwi_event id="X"] — Single event with ticket purchase
     */
    public function shortcode_single_event( $atts ) {
        $atts = shortcode_atts( array(
            'id' => 0,
        ), $atts );

        $event_id = intval( $atts['id'] );
        if ( ! $event_id ) {
            return '<p class="ke-error">Please specify an event ID.</p>';
        }

        $post = get_post( $event_id );
        if ( ! $post || $post->post_type !== 'ke_event' ) {
            return '<p class="ke-error">Event not found.</p>';
        }

        $ticket_types = new KE_Ticket_Types();
        $types = $ticket_types->get_available( $event_id );

        ob_start();
        include KE_PLUGIN_DIR . 'public/views/single-event.php';
        return ob_get_clean();
    }

    /**
     * [kiwi_checkout] — Standalone checkout form
     */
    public function shortcode_checkout( $atts ) {
        $atts = shortcode_atts( array(
            'event_id' => 0,
        ), $atts );

        $event_id = intval( $atts['event_id'] );

        ob_start();
        include KE_PLUGIN_DIR . 'public/views/checkout.php';
        return ob_get_clean();
    }

    /**
     * Override standard single_template for ke_event posts
     */
    public function override_single_template( $single_template ) {
        global $post;
        if ( $post && $post->post_type === 'ke_event' ) {
            return KE_PLUGIN_DIR . 'public/views/single-event.php';
        }
        return $single_template;
    }
}
